from flask import Flask, request
from twilio.rest import Client
import os

app = Flask(__name__)

account_sid = os.getenv('ACCOUNT_SID')
auth_token = os.getenv('AUTH_TOKEN')
from_number = 'whatsapp:+14155238886'

recipients = [
    'whatsapp:+919901849885',
    'whatsapp:+918546979139'
]

client = Client(account_sid, auth_token)

@app.route('/')
def home():
    return "✅ Stock Alert Bot Running"

@app.route('/whatsapp', methods=['POST'])
def whatsapp_webhook():
    incoming_msg = request.values.get('Body', '').strip().lower()
    from_number = request.values.get('From', '')
    response_msg = "🤖 Automated Stock Alert Bot. Please wait for updates."
    return response_msg, 200

@app.route('/send-dummy-alert', methods=['GET'])
def send_dummy_alert():
    msg = (
        "📢 *Dummy Stock Alert*
"
        "🗂️ Sample Filing
"
        "🕒 13 Jul 2025, 11:00 AM
"
        "📎 https://dummy-link.com"
    )
    for to in recipients:
        client.messages.create(body=msg, from_='whatsapp:+14155238886', to=to)
    return "✅ Dummy alert sent"

@app.route('/send-yesterday-stock-updates', methods=['GET'])
def send_yesterday_stock_updates():
    messages = [
        (
            "🧾 *Fineotex Chemicals – 12 Jul 2025*

"
            "📢 *Fineotex Chemicals*
"
            "🗂️ Regulation 30 – Director Reappointments
"
            "📋 Re-appointed: Bindu Darshan Shah, Sunil Waghmare, Sanjay Tibrewala & Surendra Tibrewala
"
            "🕒 Filing Time: 3:26 PM
"
            "📎 https://www.bseindia.com/xml-data/corpfiling/AttachLiveLink1.pdf"
        ),
        (
            "🧾 *GPT Healthcare – 12 Jul 2025*

"
            "📢 *GPT Healthcare*
"
            "🗂️ Annual Report & AGM Notice (36th AGM)
"
            "🗓️ AGM Date: 5 Aug 2025
"
            "🕒 Filing Time: 5:30 PM
"
            "📎 https://nsearchives.nseindia.com/corporate/GPTHEALTHCARE_12072025173015_GHLSubmissionofLetter36_1_12072025.pdf"
        )
    ]

    for msg in messages:
        for to in recipients:
            client.messages.create(body=msg, from_='whatsapp:+14155238886', to=to)

    return "✅ Yesterday's stock updates sent via WhatsApp!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)